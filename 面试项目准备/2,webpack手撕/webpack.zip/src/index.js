const name = require("./name");
const age = require("./age");
console.log("entry文件打印作者信息", name, age);